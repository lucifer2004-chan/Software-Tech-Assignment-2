import numpy as np
arr = np.arange(10, 19)
print("Array:", arr)
print("Shape:", arr.shape)
print("Dimension:", arr.ndim)
print("Data type:", arr.dtype)
