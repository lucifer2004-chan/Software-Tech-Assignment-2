import cv2
import numpy as np

image = cv2.imread('image.png')
inverted = 255 - image

combined = np.hstack((image, inverted))
cv2.imshow('Original and Inverted', combined)
cv2.waitKey(0)
cv2.destroyAllWindows
