import numpy as np

arr = np.arange(0, 15, 3)
sqrt_arr = np.sqrt(arr)
print(sqrt_arr)
