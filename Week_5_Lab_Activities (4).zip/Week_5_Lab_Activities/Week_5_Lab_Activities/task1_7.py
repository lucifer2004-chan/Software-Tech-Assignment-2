import numpy as np

matrix = np.arange(1, 10).reshape(3, 3)
array = np.array([1, 0, -1])
result = matrix * array

print("Matrix:\n", matrix)
print("\n1D Array:", array)
print("\nResult after broadcasting:\n", result)
