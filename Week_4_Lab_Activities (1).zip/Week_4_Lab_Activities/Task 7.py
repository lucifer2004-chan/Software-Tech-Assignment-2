from PIL import Image, ImageOps


#Image Operations

#Insect no.1

image = Image.open('Assets/Insects/2_Sphaer 2021_1_2021_06_03-11-22-54-852.PNG')

image = ImageOps.mirror(image)
image = ImageOps.scale(image, 5)
image.show()

#Insect no.2

sec_image = Image.open('Assets/Insects/1_Limniu 2021_1_2021_06_02-13-08-37-958.PNG')

sec_image = ImageOps.invert(sec_image)
sec_image = ImageOps.scale(sec_image, 5)
sec_image = ImageOps.expand(sec_image, border=10, fill=(28,220,91))
sec_image.show()

#Insect no.3

third_image = Image.open('Assets/Insects/2_Sphaer 2021_1_2021_06_03-11-22-54-873.PNG')
third_image = ImageOps.expand(third_image, border=5, fill=(255,0,201))
third_image = ImageOps.pad(third_image, (4900,8000))

third_image.show()