import numpy as np

temps = np.array([
    [[10, 15, 20], [25, 30, 35]],
    [[11, 16, 21], [26, 31, 36]]
])


second_location_temps = temps[:, 1, :]

print("Temperatures at second location (all years, all months):")
print(second_location_temps)